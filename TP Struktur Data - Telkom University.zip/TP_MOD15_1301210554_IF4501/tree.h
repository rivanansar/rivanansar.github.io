#ifndef TREE_H_INCLUDED
#define TREE_H_INCLUDED
#include <iostream>

using namespace std;
#define nil NULL

struct node{
    int data;
    node *left;
    node *right;
};

typedef node *adrNode;
typedef int infotype;

adrNode newNode_1301210554(infotype x);
adrNode findNode_1301210554(adrNode root, infotype x);
adrNode insertNode_1301210554(adrNode root, adrNode new_node);
void printPreOrder_1301210554(adrNode root);
void printDescendant_1301210554(adrNode root, infotype x);
int sumNode_1301210554(adrNode root);
int countLeaves_1301210554(adrNode root);
int heightTree_1301210554(adrNode root);

#endif // TREE_H_INCLUDED
