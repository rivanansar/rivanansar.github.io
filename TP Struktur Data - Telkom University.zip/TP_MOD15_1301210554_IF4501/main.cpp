#include <iostream>
#include "tree.h"

using namespace std;

int main()
{
    adrNode root = nil;
    cout << "\n==========================================================================" << endl;
    int x[9] = {5,3,9,10,4,7,1,8,6};

    for(int i=0; i<9; i++){
        adrNode new_node = newNode_1301210554(x[i]);
        root = insertNode_1301210554(root, new_node);
    }
    cout << "int x[9]= ";
    for(int i=0; i<9; i++){
        cout << x[i] << " ";
    }
    cout << "\n\nPre Order\t\t : ";
    printPreOrder_1301210554(root);

    cout << "\nDescendant of Node 9\t : ";
    printDescendant_1301210554(root, 9);
    cout << "\n\nSum of BST Info\t\t  : "<<sumNode_1301210554(root);
    cout << "\nNumber of Leaves\t  : "<<countLeaves_1301210554(root);
    cout << "\nHeight of Tree, with Rank : "<<heightTree_1301210554(root)-1<< "\t and Depth : " <<heightTree_1301210554(root);
    cout << "\n==========================================================================" << endl;

    return 0;
}
