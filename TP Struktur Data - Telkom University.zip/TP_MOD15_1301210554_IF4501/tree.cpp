#include "tree.h"

adrNode newNode_1301210554(infotype x){
    adrNode p = new node;
    p->data = x;
    p->left = nil;
    p->right = nil;
    return p;
}

adrNode insertNode_1301210554(adrNode root, adrNode new_node){
    if(root == nil){
        return new_node;
    }
    if(new_node->data < root->data){
        root->left = insertNode_1301210554(root->left, new_node);
    }else{
        root->right = insertNode_1301210554(root->right, new_node);
    }
    return root;
}

adrNode findNode_1301210554(adrNode root, infotype x){
    if(root == nil){
        return nil;
    }if(root->data == x){
        return root;
    }
    adrNode p = findNode_1301210554(root->left, x);
    if(p != nil){
        return p;
    }
    return findNode_1301210554(root->right, x);
}

void printPreOrder_1301210554(adrNode root){
    if(root == nil){
        return;
    }
    cout<< root->data << " ";
    printPreOrder_1301210554(root->left);
    printPreOrder_1301210554(root->right);
}

void printDescendant_1301210554(adrNode root, infotype x){
    adrNode p = findNode_1301210554(root, x);
    if(p == nil){
        cout << "Tidak Ada Node" << endl;
    }
    printPreOrder_1301210554(p->left);
    printPreOrder_1301210554(p->right);
}

int sumNode_1301210554(adrNode root){
    if(root == nil){
        return 0;
    }
    return root->data + sumNode_1301210554(root->left) + sumNode_1301210554(root->right);
}

int countLeaves_1301210554(adrNode root){
    if(root == nil){
        return 0;
    }
    if(root->left == nil && root->right == nil){
        return 1;
    }
    return countLeaves_1301210554(root->left) + countLeaves_1301210554(root->right);
}

int heightTree_1301210554(adrNode root){
    if(root == nil){
        return 0;
    }
    int left_height = heightTree_1301210554(root->left);
    int right_height = heightTree_1301210554(root->right);
    return max(left_height,right_height) +1;
}
